title: '【问题】standard_init_linux.go:195: exec user process caused "no such file or
  directory"'
date: '2019-12-07 16:16:47'
updated: '2019-12-07 16:16:47'
tags: [docker]
permalink: /articles/2019/12/07/1575706607924.html
---
## 问题描述
制作镜像完成后碰到个问题，报错显示`standard_init_linux.go:195: exec user process caused "no such file or directory"`
## 问题定位：
Dockerfile 是我在windows上写好这个文件复制过去的，因为默认使用DOC的文本格式 到了linux需要将其进行转换。
## 解决方法：
使用vim 打开Dockerfile，在命令模式下输入 `: set ff=unix`, `:wq` 保存重新制作镜像即可
